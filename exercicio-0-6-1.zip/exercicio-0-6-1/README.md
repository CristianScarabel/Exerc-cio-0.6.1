# Exercicio 0.6.1

A Pen created on CodePen.io. Original URL: [https://codepen.io/Cristian-Scarabel/pen/XWOjrQx](https://codepen.io/Cristian-Scarabel/pen/XWOjrQx).

